import React, { useEffect, useState } from "react";
import { ResponsiveContainer } from "recharts";
import { can } from "../utils/rbac.js";
import { useAuth } from "../context/RoleContext.jsx";
import { motion } from "framer-motion";
import ScrollReveal from "../ReactBits/ScrollReveal.jsx";
import MagicBento from "../ReactBits/MagicBento.jsx";
import KPITrack from "../ReactBits/KPITrack.jsx";
import Announcements from "./Announcements.jsx";
import Leaderboard from "./Leaderboard.jsx";
import AreaChart from "./charts/AreaChart.jsx";
import LineChart from "./charts/LineChart.jsx";
import PieChart from "./charts/PieChart.jsx";
import BarChart from "./charts/BarChart.jsx";

/* ===== Colors ===== */
const PIE_COLORS = ["#a5b4fc", "#86efac", "#fcd34d", "#fca5a5"];
const LINE_COLOR = "#6366f1";
const AREA_COLOR = "#22c55e";
const BAR_COLOR = "#fcd34d";

export default function AdminDashboard() {
  const { session } = useAuth();

  // ✅ Add null check
  const role = session?.role;

  const [metrics, setMetrics] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const res = await fetch("http://localhost:4000/api/admin/metrics");
        const data = await res.json();

        if (!res.ok) {
          throw new Error(data.error || "Failed to load metrics");
        }

        setMetrics(data);
      } catch (err) {
        console.error("Error fetching metrics:", err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchMetrics();
  }, []);

  if (!session) {
    return (
      <div className="text-center mt-20 text-gray-500">
        You are not logged in. Please <a href="/login" className="text-indigo-600">login</a>.
      </div>
    );
  }

  if (loading)
    return <div className="text-center mt-20">Loading dashboard...</div>;

  if (!metrics)
    return <div className="text-center mt-20 text-red-500">Failed to load metrics.</div>;

  return (
    <div className="space-y-8">
      {/* KPIs */}
      {can(role, "kpis") && (
        <KPITrack
          items={[
            { title: "Active Users", value: metrics.activeUsers, helper: "+9% WoW", color: "#a5b4fc" },
            { title: "Completion Rate", value: metrics.completionRate + "%", helper: "Target 80%", color: "#86efac" },
            { title: "Avg Session (min)", value: metrics.avgSessionMins, helper: "Last 7 days", color: "#fcd34d" },
            { title: "New Signups", value: metrics.newSignups, helper: "This week", color: "#fca5a5" },
          ]}
        />
      )}

      {/* Completion Trend */}
      {can(role, "completionChart") && (
        <MagicBento title="Completion Trend" spotlightColor="rgba(34, 197, 94, 0.14)">
          <ScrollReveal>
            <div className="h-72">
              <ResponsiveContainer>
                <AreaChart
                  data={metrics.completionTrend}
                  dataKey="rate"
                  xLabel="week"
                  strokeColor={AREA_COLOR}
                  gradientId="completionTrendGradient"
                  height={250}
                />
              </ResponsiveContainer>
            </div>
          </ScrollReveal>
        </MagicBento>
      )}

      {/* ...rest of your code remains the same... */}
      {/* Just ensure role is only accessed if session exists */}
    </div>
  );
}

/* Table helpers */
const Th = ({ children }) => <th className="text-left px-4 py-2 font-semibold">{children}</th>;
const Td = ({ children }) => <td className="px-4 py-2">{children}</td>;
