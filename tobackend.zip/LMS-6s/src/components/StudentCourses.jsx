import React, { useState } from "react";

export default function StudentCourses() {
  const [availableCourses, setAvailableCourses] = useState([
    { id: 1, name: "React Basics" },
    { id: 2, name: "Node.js Fundamentals" },
    { id: 3, name: "Database Design" },
  ]);

  const [enrolledCourses, setEnrolledCourses] = useState([]);
  const [completedCourses, setCompletedCourses] = useState([]);

  const handleEnroll = (course) => {
    setEnrolledCourses([...enrolledCourses, course]);
    setAvailableCourses(availableCourses.filter((c) => c.id !== course.id));
  };

  const handleComplete = (course) => {
    setCompletedCourses([...completedCourses, course]);
    setEnrolledCourses(enrolledCourses.filter((c) => c.id !== course.id));
  };

  return (
    <div className="space-y-6">
      {/* Available Courses */}
      <div>
        <h2 className="text-xl font-semibold mb-2">Available Courses</h2>
        {availableCourses.length > 0 ? (
          <ul className="space-y-2">
            {availableCourses.map((course) => (
              <li
                key={course.id}
                className="flex justify-between p-2 border rounded"
              >
                {course.name}
                <button
                  className="bg-blue-500 text-white px-3 py-1 rounded"
                  onClick={() => handleEnroll(course)}
                >
                  Enroll
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p>No courses available</p>
        )}
      </div>

      {/* Enrolled Courses */}
      <div>
        <h2 className="text-xl font-semibold mb-2">Enrolled Courses</h2>
        {enrolledCourses.length > 0 ? (
          <ul className="space-y-2">
            {enrolledCourses.map((course) => (
              <li
                key={course.id}
                className="flex justify-between p-2 border rounded"
              >
                {course.name}
                <button
                  className="bg-green-500 text-white px-3 py-1 rounded"
                  onClick={() => handleComplete(course)}
                >
                  Mark Complete
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p>No enrolled courses</p>
        )}
      </div>

      {/* Completed Courses */}
      <div>
        <h2 className="text-xl font-semibold mb-2">Completed Courses</h2>
        {completedCourses.length > 0 ? (
          <ul className="space-y-2">
            {completedCourses.map((course) => (
              <li
                key={course.id}
                className="p-2 border rounded bg-gray-100"
              >
                {course.name}
              </li>
            ))}
          </ul>
        ) : (
          <p>No completed courses</p>
        )}
      </div>
    </div>
  );
}
