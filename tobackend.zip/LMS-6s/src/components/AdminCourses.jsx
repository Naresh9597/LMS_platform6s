import React, { useState } from "react";

export default function AdminCourses() {
  const [courses, setCourses] = useState([
    { id: 1, name: "React Basics" },
    { id: 2, name: "Node.js Fundamentals" },
  ]);
  const [newCourse, setNewCourse] = useState("");

  const handleAddCourse = () => {
    if (!newCourse) return;
    const newEntry = { id: Date.now(), name: newCourse };
    setCourses([...courses, newEntry]);
    setNewCourse("");
  };

  const handleDeleteCourse = (id) => {
    setCourses(courses.filter((c) => c.id !== id));
  };

  return (
    <div className="space-y-6">
      {/* Existing Courses */}
      <div>
        <h2 className="text-xl font-semibold mb-2">Courses Available</h2>
        {courses.length > 0 ? (
          <ul className="space-y-2">
            {courses.map((course) => (
              <li
                key={course.id}
                className="flex justify-between p-2 border rounded"
              >
                {course.name}
                <button
                  className="bg-red-500 text-white px-3 py-1 rounded"
                  onClick={() => handleDeleteCourse(course.id)}
                >
                  Delete
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <p>No courses available</p>
        )}
      </div>

      {/* Add New Course */}
      <div>
        <h2 className="text-xl font-semibold mb-2">Add New Course</h2>
        <div className="flex gap-2">
          <input
            type="text"
            placeholder="Course name"
            value={newCourse}
            onChange={(e) => setNewCourse(e.target.value)}
            className="border px-2 py-1 rounded flex-1"
          />
          <button
            className="bg-blue-500 text-white px-4 py-1 rounded"
            onClick={handleAddCourse}
          >
            Add
          </button>
        </div>
      </div>
    </div>
  );
}
