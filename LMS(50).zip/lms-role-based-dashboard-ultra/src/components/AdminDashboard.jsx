import React from 'react'
import { adminMetrics } from '../data/mock.js'
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area, PieChart, Pie, Cell, BarChart, Bar } from 'recharts'
import { can } from '../utils/rbac.js'
import { useAuth } from '../context/RoleContext.jsx'

const PIE_COLORS = ['#6366f1','#22c55e','#f59e0b','#ef4444']

export default function AdminDashboard() {
  const { session } = useAuth()
  const role = session.role
  return (
    <div className="space-y-6">
      {can(role, 'kpis') && (
        <div className="grid-cards">
          <KPI title="Active Users" value={adminMetrics.activeUsers} helper="+9% WoW" />
          <KPI title="Completion Rate" value={adminMetrics.completionRate + '%'} helper="Target 80%" />
          <KPI title="Avg Session (min)" value={adminMetrics.avgSessionMins} helper="Last 7 days" />
          <KPI title="New Signups" value={adminMetrics.newSignups} helper="This week" />
        </div>
      )}

      {can(role, 'completionChart') && (
        <div className="card p-4">
          <h3 className="font-semibold mb-2">Completion Trend</h3>
          <div className="h-72">
            <ResponsiveContainer>
              <AreaChart data={adminMetrics.completionTrend.map((v,i)=>({week:'W'+(i+1), rate:v}))}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" />
                <YAxis />
                <Tooltip />
                <Area type="monotone" dataKey="rate" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      <div className="grid lg:grid-cols-2 gap-4">
        {can(role, 'orgStats') && (
          <div className="card p-4">
            <h3 className="font-semibold mb-2">Weekly Active Users</h3>
            <div className="h-72">
              <ResponsiveContainer>
                <LineChart data={adminMetrics.weeklyActive.map((v,i)=>({day:'D'+(i+1), users:v}))}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="users" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
        {can(role, 'distributionChart') && (
          <div className="card p-4">
            <h3 className="font-semibold mb-2">Course Distribution</h3>
            <div className="h-72">
              <ResponsiveContainer>
                <PieChart>
                  <Pie data={adminMetrics.courseDistribution} dataKey="value" outerRadius={90}>
                    {adminMetrics.courseDistribution.map((_,i)=>(<Cell key={i} fill={PIE_COLORS[i%PIE_COLORS.length]} />))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </div>

      {can(role, 'ratingBreakdown') && (
        <div className="card p-4">
          <h3 className="font-semibold mb-2">Ratings Breakdown</h3>
          <div className="h-72">
            <ResponsiveContainer>
              <BarChart data={adminMetrics.ratingBuckets.map(b=>({bucket:b.label, count:b.value}))}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="bucket" /><YAxis /><Tooltip />
                <Bar dataKey="count" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {can(role, 'coursesTable') && (
        <div className="card overflow-hidden">
          <div className="px-4 py-3 border-b dark:border-white/10 flex items-center justify-between">
            <h3 className="font-semibold">Courses Overview</h3>
            <span className="badge">Admin-only</span>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="table-head">
                <tr><Th>Course</Th><Th>Enrollments</Th><Th>Completion %</Th><Th>Rating</Th></tr>
              </thead>
              <tbody>
                {adminMetrics.courses.map(c => (
                  <tr key={c.id} className="table-row">
                    <Td>{c.title}</Td>
                    <Td>{c.enrollments}</Td>
                    <Td>{c.completion}%</Td>
                    <Td>{'★'.repeat(Math.round(c.rating))} ({c.rating})</Td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <div className="grid lg:grid-cols-2 gap-4">
        {can(role, 'leaderboard') && <Leaderboard />}
        {can(role, 'announcements') && <Announcements items={adminMetrics.announcements} />}
      </div>

      {can(role, 'trending') && (
        <div className="card p-4">
          <h3 className="font-semibold mb-2">Trending Courses</h3>
          <div className="grid sm:grid-cols-2 gap-3">
            {adminMetrics.topCourses.map(c => (
              <div key={c.name} className="kpi">
                <div className="text-sm text-gray-500 dark:text-gray-400">{c.name}</div>
                <div className="text-2xl font-bold mt-1">{c.enrollments} enrollments</div>
                <div className="text-xs opacity-70 mt-1">Rating {c.rating}★</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function KPI({ title, value, helper }) {
  return (
    <div className="kpi">
      <div className="text-sm text-gray-500 dark:text-gray-400">{title}</div>
      <div className="text-3xl font-extrabold mt-1">{value}</div>
      <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">{helper}</div>
    </div>
  )
}

function Leaderboard() {
  return (
    <div className="card overflow-hidden">
      <div className="px-4 py-3 border-b dark:border-white/10 flex items-center justify-between">
        <h3 className="font-semibold">Student Leaderboard</h3>
        <span className="badge">Top 5</span>
      </div>
      <div className="divide-y dark:divide-white/10">
        {adminMetrics.leaderboard.map((s,idx)=>(
          <div key={s.id} className="px-4 py-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full grid place-items-center bg-black/5 dark:bg-white/10">{idx+1}</div>
              <div>{s.name}</div>
            </div>
            <div className="font-semibold">{s.score}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

function Announcements({ items }) {
  return (
    <div className="card overflow-hidden">
      <div className="px-4 py-3 border-b dark:border-white/10 flex items-center justify-between">
        <h3 className="font-semibold">Announcements</h3>
      </div>
      <div className="divide-y dark:divide-white/10">
        {items.map(a => (
          <div key={a.id} className="px-4 py-3">
            <div className="text-sm text-gray-500 dark:text-gray-400">{a.date}</div>
            <div className="font-semibold">{a.title}</div>
            <div className="text-sm">{a.text}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

const Th = ({ children }) => <th className="text-left px-4 py-2 font-semibold">{children}</th>
const Td = ({ children }) => <td className="px-4 py-2">{children}</td>
