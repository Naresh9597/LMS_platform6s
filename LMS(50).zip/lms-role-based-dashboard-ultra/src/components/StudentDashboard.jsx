import React from 'react'
import { studentData } from '../data/mock.js'
import { LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, ResponsiveContainer, AreaChart, Area, RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis } from 'recharts'
import { can } from '../utils/rbac.js'
import { useAuth } from '../context/RoleContext.jsx'

export default function StudentDashboard() {
  const { session } = useAuth()
  const role = session.role
  const avgScore = Math.round(studentData.progress.reduce((a,b)=>a+b.score,0)/studentData.progress.length)
  const totalMinutes = studentData.timeSpent.reduce((a,b)=>a+b.minutes,0)
  return (
    <div className="space-y-6">
      {can(role, 'kpis') && (
        <div className="grid-cards">
          <KPI title="Avg Weekly Score" value={avgScore + '%'} helper="Last 6 weeks" />
          <KPI title="Time Spent" value={totalMinutes + ' min'} helper="Total study time" />
          <KPI title="Upcoming Tasks" value={studentData.deadlines.length} helper="Next 10 days" />
          <KPI title="Quizzes Taken" value={studentData.quizHistory.length} helper="Recent" />
        </div>
      )}

      {can(role, 'progressChart') && (
        <div className="card p-4">
          <h3 className="font-semibold mb-2">Weekly Progress</h3>
          <div className="h-72">
            <ResponsiveContainer>
              <LineChart data={studentData.progress}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="week" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="score" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      <div className="grid lg:grid-cols-2 gap-4">
        {can(role, 'timeSpentChart') && (
          <div className="card p-4">
            <h3 className="font-semibold mb-2">Study Time</h3>
            <div className="h-72">
              <ResponsiveContainer>
                <AreaChart data={studentData.timeSpent}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="week" />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="minutes" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
        {can(role, 'topicMasteryChart') && (
          <div className="card p-4">
            <h3 className="font-semibold mb-2">Topic Mastery</h3>
            <div className="h-72">
              <ResponsiveContainer>
                <RadarChart data={studentData.topicMastery}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="topic" />
                  <PolarRadiusAxis />
                  <Radar name="Mastery" dataKey="mastery" />
                  <Tooltip />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        {can(role, 'deadlinesTable') && <Deadlines />}
        {can(role, 'quizTable') && <QuizHistory />}
      </div>

      <Announcements items={studentData.announcements} />
    </div>
  )
}

function KPI({ title, value, helper }) {
  return (
    <div className="kpi">
      <div className="text-sm text-gray-500 dark:text-gray-400">{title}</div>
      <div className="text-3xl font-extrabold mt-1">{value}</div>
      <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">{helper}</div>
    </div>
  )
}

function Deadlines() {
  return (
    <div className="card overflow-hidden">
      <div className="px-4 py-3 border-b dark:border-white/10 flex items-center justify-between">
        <h3 className="font-semibold">Upcoming Deadlines</h3>
        <span className="badge">Student</span>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead className="table-head"><tr><Th>Course</Th><Th>Task</Th><Th>Due</Th></tr></thead>
          <tbody>
            {studentData.deadlines.map(d => (
              <tr key={d.id} className="table-row">
                <Td>{d.course}</Td><Td>{d.task}</Td><Td>{d.due}</Td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function QuizHistory() {
  return (
    <div className="card overflow-hidden">
      <div className="px-4 py-3 border-b dark:border-white/10 flex items-center justify-between">
        <h3 className="font-semibold">Quiz History</h3>
        <span className="badge">Student</span>
      </div>
      <div className="overflow-x-auto">
        <table className="min-w-full text-sm">
          <thead className="table-head"><tr><Th>Course</Th><Th>Score</Th><Th>Date</Th></tr></thead>
          <tbody>
            {studentData.quizHistory.map(q => (
              <tr key={q.id} className="table-row">
                <Td>{q.course}</Td><Td>{q.score}</Td><Td>{q.date}</Td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function Announcements({ items }) {
  return (
    <div className="card overflow-hidden">
      <div className="px-4 py-3 border-b dark:border-white/10 flex items-center justify-between">
        <h3 className="font-semibold">Announcements</h3>
      </div>
      <div className="divide-y dark:divide-white/10">
        {items.map(a => (
          <div key={a.id} className="px-4 py-3">
            <div className="text-sm text-gray-500 dark:text-gray-400">{a.date}</div>
            <div className="font-semibold">{a.title}</div>
            <div className="text-sm">{a.text}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

const Th = ({ children }) => <th className="text-left px-4 py-2 font-semibold">{children}</th>
const Td = ({ children }) => <td className="px-4 py-2">{children}</td>
