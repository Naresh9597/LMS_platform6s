/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ["./index.html","./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      boxShadow: {
        soft: "0 10px 30px -12px rgba(0,0,0,.25)",
        glass: "inset 0 1px 0 rgba(255,255,255,.06), 0 10px 30px -12px rgba(0,0,0,.35)"
      },
      colors: { brand: { 500: "#6d5dfc", 600: "#5c4ef7", 700: "#4b3ef1" } },
      borderRadius: { xl2: "1.25rem" }
    },
  },
  plugins: [],
}
